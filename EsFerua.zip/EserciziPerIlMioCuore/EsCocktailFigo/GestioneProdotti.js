import Prodotto from "./prodotto.js";
import Categoria from "./categoria.js";


let prodotti = [];
let categorie = [];

let idMenu = "Selezione";

function popolaArray(data){
    
    data.forEach((item)=>{
        let temp = new Prodotto(item.category, item.createdAt, item.description, item.id, item.image, item.name, item.price, item.quantity);

        if(prodotti==""){
            prodotti[0] = temp;
        }

        else{
            prodotti.push(temp);
        }
        
    });

}

function popolaArrayCategory(data){
    
    data.forEach((item)=>{
        let temp = new Categoria(item.createdAt, item.name, item.id);

        if(categorie==""){
            categorie[0] = temp;
        }

        else{
            categorie.push(temp);
        }
        
    });

}

function stampaProdotti(){
    prodotti.forEach(prodotto => {
        console.log(prodotto.toString());
    })
}

function openDataBase(){
    let url = "https://67e6e4e76530dbd31111d68c.mockapi.io/api/products";
    fetch(url)
    .then(result=>result.json())
    .then(data=>{
        popolaArray(data);
    })
    .then( stampaProdotti )
    .then(stampaTabella);
    

    
}

function openDataBaseCategory(){
    let url = "https://67e6e4e76530dbd31111d68c.mockapi.io/api/category";
    fetch(url)
    .then(result=>result.json())
    .then(data=>{
        popolaArrayCategory(data);
    })
    .then(stampaMenu)
    .then(gestioneMenu)
    
}

function stampaTabella(){

    console.log("\n\n\nSTAMPO\n\n\n");
    const bodyTabellaProdotti = document.querySelector('#tabella');
    bodyTabellaProdotti.innerHTML = "";

    let stampa;
    let menu = document.getElementById("productCategory");

    console.log("\n\n\n"+menu.value+"\n\n\n");

    if(menu.value == "Tutti"){
        stampa = prodotti;
    }

    else{
        stampa = prodotti.filter(prodotto => {
            if(prodotto.category == menu.value)
                return true;
        })
    }

    stampa.forEach((prodotto)=>{

        console.log(prodotto.toString());
        const riga = document.createElement("tr");
        riga.innerHTML = prodotto.toTableRow();

        bodyTabellaProdotti.appendChild(riga);


    });


}

function stampaMenu(){
    const bodyMenu = document.querySelector('#productCategory');
    //bodyMenu.innerHTML = "";

    categorie.forEach((categoria)=>{

        console.log(categoria.toString());
        const riga = document.createElement("option");
        riga.textContent = categoria.name;
        riga.value = categoria.name;
        riga.className = "selezione";
        bodyMenu.appendChild(riga);


    });

}

function gestioneMenu(){

    let selezioni = document.getElementById("productCategory");

    selezioni.addEventListener("click", stampaTabella);
}

document.addEventListener("DOMContentLoaded" ,(event) => {
    
    openDataBase()

    openDataBaseCategory();
   
});




