import Drink from "./drink.js";


let myDrinks = [];


function card(){
    const bodyCards = document.getElementById('vetrina');
    bodyCards.innerHTML = "";

    myDrinks.forEach((drink)=>{

        //console.log(categoria.toString());
        const riga = document.createElement("div");
        riga.innerHTML = drink.toCard();
        bodyCards.appendChild(riga);

    });

    gestioneDescrizioni();

}

function popolaDrink(data){

    myDrinks = [];
    data.drinks.forEach(drink => {
        let temp = new Drink(drink.idDrink, drink.strDrink,drink.strDrinkThumb, drink.strInstructions);
        if(myDrinks == "")
            myDrinks[0] = temp;
        else
            myDrinks.push(temp);
    });
}

function aggiungiElemento(){
    
    let nomeDrink = document.getElementById("drinkName").value;

    if(nomeDrink==""){
        alert("Non è stato inserito alcun drink")
    }

    else{

    let url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s="

    url = url+nomeDrink;

    fetch(url)
    .then(result=>result.json())
    .then(data=>{
        console.log(data.drinks);
        popolaDrink(data)
    })
    .then(card())
    .then(gestioneDescrizioni())
    }
    

    
}

function gestioneRicerca(){
    let btnAdd = document.getElementById("searchBtn");
    btnAdd.addEventListener("click", aggiungiElemento);
}

function stampaDescrizione(id){


    console.log("SONO DENTRO MI HAI CLICCATO "+id);


    let drink = myDrinks.find(dri => {
        if(dri.idDrink == id) return true;
    })

    console.log("SONO IL DRINK"+drink.idDrink)

    let description = document.getElementById("descrizione");
    description.innerHTML = "";

    const titleDrink = document.createElement("h1");
    titleDrink.innerHTML = drink.strDrink;
    description.appendChild(titleDrink);

    const descDrink = document.createElement("div");
    descDrink.innerHTML = drink.strInstructions;
    description.appendChild(descDrink);

    
}

function gestioneDescrizioni(){
    
    

    let buttons = document.querySelectorAll(".btnDesc");

    buttons.forEach(button =>{
        console.log("SONO DENTRO "+button.id);
        button.addEventListener("click", ()=>{
            stampaDescrizione(button.id);
        });

    })

}

function mostraCarrello(){
    let testaTabella = document.getElementById("cart")
    testaTabella.style= "display: block";
}

function gestioneCart(){
    let button = document.getElementById("showCart");
    button.addEventListener("click", mostraCarrello);
}


document.addEventListener("DOMContentLoaded" ,(event) => {
    
    gestioneCart();

    gestioneRicerca();

});
