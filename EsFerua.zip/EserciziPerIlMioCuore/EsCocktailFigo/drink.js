class Prodotto{

    constructor(idDrink, strDrink,strDrinkThumb, strInstructions ){
        this.idDrink = idDrink;
        this.strDrink = strDrink;
        this.strDrinkThumb = strDrinkThumb;
        this.strInstructions = strInstructions;
    }


    

    toString(){
        return `Category: ${this.category} createdAt: ${this.createdAt} Description: ${this.description} image: ${this.image} Name: ${this.name} Price: ${this.price} Quantity: ${this.quantity}`;
    }

    toCard(){
        return `<img src = ${this.strDrinkThumb} style="width:50%">
                        
                        <h4><b>${this.strDrink}</b></h4>
                        <div>
                         <button type="button" class="btnDesc" id="${this.idDrink}"> Descrizione </button></div>`;
    }

}
//<div> ${this.description} 

export default Prodotto; //Permette di esportare la classe prodotto