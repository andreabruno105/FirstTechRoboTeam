/*********
utilizzo il webserver di VSC 
**********/
let url = "./comuni_completo.json" //url che punta al json... può essere anche un url sul web
                                  //potrà essere anche un http://www....

function scorriComuni(){

    if(document.getElementById("regione").value!="")
    {
        fetch(url)
            .then(response => response.json()) //richiamo la funzione json
            .then(dati => {
                const datiJson = dati
                //console.log(datiJson) //stampo l'oggetto creato dall'importazione del json
                        
                //console.log("comune nome = " + datiJson.regione_nome)


                let arrayRegione = datiJson.filter(element => {
                    if(element.regione.nome == document.getElementById("regione").value)
                        return true;
                });

                document.getElementById("stampa").innerHTML = "";
                

                arrayRegione.forEach(element => {
                    const riga = document.createElement("div");
                    console.log(element.nome);
                    riga.innerHTML = element.nome;
                    document.getElementById("stampa").appendChild(riga);
                })


                // datiJson.forEach(element =>{ //scorro l'array di oggetti presente in provincia
                //     console.log("--"+ element.nome)
                //     if(element.cap.length>0){
                //         element.cap.forEach(cap=>{
                //             console.log("---"+ cap);
                //         });
                //     }
                // });
                

            });

        
        

    }

    else
        alert("Non hai inserito nessuna regione");

    //document.getElementById("comune").value=null;
}                                

function aggiungiEventoRicerca(){
    const btnCerca = document.getElementById("find");
    btnCerca.addEventListener("click", scorriComuni);
}


            
aggiungiEventoRicerca();