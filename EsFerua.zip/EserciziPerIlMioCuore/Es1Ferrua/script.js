/*********
utilizzo il webserver di VSC 
**********/
let url = "./comuni_completo.json" //url che punta al json... può essere anche un url sul web
                                  //potrà essere anche un http://www....

function scorriComuni(){

    if(document.getElementById("comune").value!="")
    {
        fetch(url)
            .then(response => response.json()) //richiamo la funzione json
            .then(dati => {
                const datiJson = dati
                //console.log(datiJson) //stampo l'oggetto creato dall'importazione del json
                        
                //console.log("comune nome = " + datiJson.regione_nome)


                let comune = datiJson.find(element => {
                    if(element.nome == document.getElementById("comune").value)
                        return true;
                });

                console.log(comune.cap);

                // datiJson.forEach(element =>{ //scorro l'array di oggetti presente in provincia
                //     console.log("--"+ element.nome)
                //     if(element.cap.length>0){
                //         element.cap.forEach(cap=>{
                //             console.log("---"+ cap);
                //         });
                //     }
                // });
                document.getElementById("stampa").innerHTML = "";
                const riga = document.createElement("div");
                riga.innerHTML = comune.cap;
                document.getElementById("stampa").appendChild(riga);

            });

        
        

    }

    else
        alert("Non hai inserito nessun comune");

    //document.getElementById("comune").value=null;
}                                

function aggiungiEventoRicerca(){
    const btnCerca = document.getElementById("find");
    btnCerca.addEventListener("click", scorriComuni);
}


            
aggiungiEventoRicerca();